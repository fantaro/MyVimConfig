# 3x C-Down, i
keys('\<C-Down>\<C-Down>\<C-Down>')
keys('i')
keys('Hello')
keys('\<Esc>')
